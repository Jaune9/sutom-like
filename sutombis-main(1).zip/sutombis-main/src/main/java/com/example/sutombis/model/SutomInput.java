package com.example.sutombis.model;

public class SutomInput {

    private String proposedWord;

    public String getProposedWord() {
        return proposedWord;
    }

    public void setProposedWord(String userInput) {
        this.proposedWord = userInput;
    }

}
