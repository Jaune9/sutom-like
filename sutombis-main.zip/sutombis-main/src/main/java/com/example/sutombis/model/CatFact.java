package com.example.sutombis.model;

public class CatFact {
    private long id;
    private String fact;
    private Number length;

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getFact() {
    return fact;
  }

  public void setFact(String fact) {
    this.fact = fact;
  }

  public Number getLength() {
    return length;
  }

  public void setLength(Number length) {
    this.length = length;
  }


}
