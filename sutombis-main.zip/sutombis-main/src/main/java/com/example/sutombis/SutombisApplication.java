package com.example.sutombis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SutombisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SutombisApplication.class, args);
	}

}
